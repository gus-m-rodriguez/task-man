import React from 'react'

function TareaFormPage() {
  return (
    <div>
      <h1>Tarea Form</h1>
        <p>This is the tarea form page of our application.</p>
    </div>
  )
}

export default TareaFormPage
