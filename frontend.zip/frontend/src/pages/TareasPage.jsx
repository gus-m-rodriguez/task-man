import React from 'react'

function TareasPage() {
  return (
    <div>
      <h1>Tareas</h1>
      <p>Esta es la página de tareas de nuestra aplicación.</p>
    </div>
  )
}

export default TareasPage
